package ru.renoviso.smokefree;
import android.content.*;
public class AlarmReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){Alarms.notifyDue(c,i.getLongExtra("due",0));} }
