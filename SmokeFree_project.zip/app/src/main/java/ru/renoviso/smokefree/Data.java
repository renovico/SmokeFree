package ru.renoviso.smokefree;
import android.content.*;import java.time.*;import org.json.*;
final class Data {
 static android.content.SharedPreferences p(Context c){return c.getSharedPreferences("course",0);}
 static int day(Context c){String s=p(c).getString("start","");return s.isEmpty()?0:(int)java.time.temporal.ChronoUnit.DAYS.between(LocalDate.parse(s),LocalDate.now())+1;}
 static int limit(int d){return d<1||d>25?0:d<=3?6:d<=12?5:d<=16?4:d<=20?3:1;}
 static long interval(int d){return (d<=3?120:d<=12?150:d<=16?180:d<=20?300:1440)*60000L;}
 static JSONArray history(Context c){try{return new JSONArray(p(c).getString("history","[]"));}catch(JSONException e){throw new IllegalStateException("Ошибка чтения истории",e);}}
 static int imported(Context c){return LocalDate.now().toString().equals(p(c).getString("importDate",""))?p(c).getInt("importCount",0):0;}
 static int count(Context c){int count=imported(c);String today=LocalDate.now().toString();JSONArray a=history(c);for(int i=0;i<a.length();i++){JSONObject o=a.optJSONObject(i);if(o!=null&&today.equals(o.optString("date")))count++;}return count;}
 static void add(Context c,long due){try{JSONArray a=history(c);JSONObject o=new JSONObject();o.put("time",System.currentTimeMillis());o.put("date",LocalDate.now().toString());o.put("day",day(c));a.put(o);if(!p(c).edit().putString("history",a.toString()).putLong("due",due).putLong("alerted",0).commit())throw new IllegalStateException("Не удалось сохранить приём");}catch(JSONException e){throw new IllegalStateException(e);}}
 static String time(long t){return java.time.Instant.ofEpochMilli(t).atZone(ZoneId.systemDefault()).format(java.time.format.DateTimeFormatter.ofPattern("dd.MM HH:mm"));}
}
