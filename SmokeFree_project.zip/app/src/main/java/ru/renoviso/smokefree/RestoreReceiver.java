package ru.renoviso.smokefree;
import android.content.*;
public class RestoreReceiver extends BroadcastReceiver { @Override public void onReceive(Context c,Intent i){try{Alarms.channel(c);Alarms.restore(c);}catch(SecurityException e){android.util.Log.w("SmokeFree","Нет разрешения",e);}} }
