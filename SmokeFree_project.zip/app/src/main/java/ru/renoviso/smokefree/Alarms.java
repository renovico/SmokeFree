package ru.renoviso.smokefree;
import android.app.*;import android.content.*;import android.os.*;
final class Alarms {
 static final String CHANNEL="dose_reminders";
 static AlarmManager manager(Context c){return (AlarmManager)c.getSystemService(Context.ALARM_SERVICE);}
 static void channel(Context c){NotificationChannel ch=new NotificationChannel(CHANNEL,"Напоминания о приёме",NotificationManager.IMPORTANCE_HIGH);ch.enableVibration(true);((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).createNotificationChannel(ch);}
 static boolean exact(Context c){return Build.VERSION.SDK_INT<31||manager(c).canScheduleExactAlarms();}
 static boolean notifications(Context c){if(Build.VERSION.SDK_INT>=33&&c.checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)return false;NotificationManager n=(NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE);NotificationChannel ch=n.getNotificationChannel(CHANNEL);return n.areNotificationsEnabled()&&(ch==null||ch.getImportance()!=NotificationManager.IMPORTANCE_NONE);}
 static PendingIntent pending(Context c,long due){return PendingIntent.getBroadcast(c,1,new Intent(c,AlarmReceiver.class).putExtra("due",due),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);}
 static void cancel(Context c){manager(c).cancel(pending(c,0));((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).cancel(10);}
 static void schedule(Context c,long due){if(!exact(c))throw new SecurityException("Разреши точные напоминания");manager(c).setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP,SystemClock.elapsedRealtime()+Math.max(1000,due-System.currentTimeMillis()),pending(c,due));}
 static void restore(Context c){long due=Data.p(c).getLong("due",0);if(due>0&&Data.p(c).getLong("alerted",0)!=due&&exact(c))schedule(c,due);}
 static void notifyDue(Context c,long due){
  if(due<=0||due!=Data.p(c).getLong("due",0)||Data.p(c).getLong("alerted",0)==due)return;
  channel(c);if(!notifications(c))return;
  PendingIntent open=PendingIntent.getActivity(c,0,new Intent(c,MainActivity.class),PendingIntent.FLAG_UPDATE_CURRENT|PendingIntent.FLAG_IMMUTABLE);
  Notification n=new Notification.Builder(c,CHANNEL).setSmallIcon(R.drawable.ic_notification).setContentTitle("Курс без дыма — таймер завершён").setContentText("Приём отмечается только вручную. Открой приложение.").setStyle(new Notification.BigTextStyle().bigText("Установленный тобой интервал завершён. Проверь схему приёма. Уведомление не отмечает приём и не запускает следующий отсчёт.")).setContentIntent(open).setAutoCancel(true).setCategory(Notification.CATEGORY_REMINDER).setVisibility(Notification.VISIBILITY_PRIVATE).build();
  ((NotificationManager)c.getSystemService(Context.NOTIFICATION_SERVICE)).notify(10,n);Data.p(c).edit().putLong("alerted",due).apply();
 }
}
