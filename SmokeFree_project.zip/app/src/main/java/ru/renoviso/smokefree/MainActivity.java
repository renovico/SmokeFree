package ru.renoviso.smokefree;
import android.app.*;import android.os.*;import android.content.*;import android.content.res.*;import android.graphics.Color;import android.graphics.drawable.*;import android.net.Uri;import android.provider.Settings;import android.view.*;import android.widget.*;import java.time.*;import org.json.*;
public class MainActivity extends Activity {
 LinearLayout body;TextView clock;int tab=0,fg,bg,card,accent,renderedDay=-999;boolean dark,failed=false;
 Handler handler=new Handler(Looper.getMainLooper());Runnable ticker=new Runnable(){public void run(){try{refreshClock();}catch(RuntimeException e){failure(e);}handler.postDelayed(this,1000);}};
 @Override public void onCreate(Bundle state){super.onCreate(state);try{
  String theme=Data.p(this).getString("theme","system");dark=theme.equals("dark")||(theme.equals("system")&&(getResources().getConfiguration().uiMode&Configuration.UI_MODE_NIGHT_MASK)==Configuration.UI_MODE_NIGHT_YES);
  setTheme(dark?android.R.style.Theme_Material_NoActionBar:android.R.style.Theme_Material_Light_NoActionBar);
  fg=dark?0xffe8f5ef:0xff162b27;bg=dark?0xff111c1a:0xfff1f7f4;card=dark?0xff1e302c:Color.WHITE;accent=dark?0xff7cdbc0:0xff176c55;
  if(state!=null)tab=state.getInt("tab",0);Alarms.channel(this);Alarms.restore(this);draw();
 }catch(RuntimeException|LinkageError e){failure(e);}}
 @Override protected void onResume(){super.onResume();handler.post(ticker);if(body!=null&&!failed)draw();}
 @Override protected void onPause(){handler.removeCallbacks(ticker);super.onPause();}
 @Override public void onSaveInstanceState(Bundle b){b.putInt("tab",tab);super.onSaveInstanceState(b);}
 int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
 TextView text(String s,int size){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(fg);t.setPadding(0,dp(8),0,dp(8));body.addView(t);return t;}
 void style(Button b,boolean active){b.setAllCaps(false);b.setTextColor(active?bg:accent);b.setBackgroundTintList(null);GradientDrawable shape=new GradientDrawable();shape.setColor(active?accent:card);shape.setCornerRadius(dp(14));shape.setStroke(dp(1),accent);b.setBackground(new RippleDrawable(ColorStateList.valueOf(0x337fba9e),shape,null));b.setPadding(dp(8),dp(12),dp(8),dp(12));b.setMinimumHeight(dp(48));}
 void button(String title,Runnable action){Button b=new Button(this);b.setText(title);style(b,false);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,-2);lp.setMargins(0,dp(6),0,dp(6));body.addView(b,lp);b.setOnClickListener(v->{try{action.run();}catch(RuntimeException e){failure(e);}});}
 void draw(){try{drawContent();}catch(RuntimeException|LinkageError e){failure(e);}}
 void drawContent(){
  if(failed)return;clock=null;renderedDay=Data.day(this);
  LinearLayout outer=new LinearLayout(this);outer.setOrientation(1);outer.setBackgroundColor(bg);outer.setPadding(dp(16),dp(12),dp(16),dp(16));
  if(Build.VERSION.SDK_INT>=30)getWindow().setDecorFitsSystemWindows(false);
  outer.setOnApplyWindowInsetsListener((v,insets)->{try{
   int l,t,r,b;if(Build.VERSION.SDK_INT>=30){android.graphics.Insets safe=insets.getInsets(WindowInsets.Type.systemBars()|WindowInsets.Type.displayCutout()|WindowInsets.Type.ime());l=safe.left;t=safe.top;r=safe.right;b=safe.bottom;}else{l=insets.getSystemWindowInsetLeft();t=insets.getSystemWindowInsetTop();r=insets.getSystemWindowInsetRight();b=insets.getSystemWindowInsetBottom();}v.setPadding(dp(16)+l,dp(12)+t,dp(16)+r,dp(16)+b);
  }catch(RuntimeException e){v.post(()->failure(e));}return insets;});
  setContentView(outer);outer.requestApplyInsets();TextView title=new TextView(this);title.setText("Курс без дыма");title.setTextColor(fg);title.setTextSize(25);outer.addView(title);
  LinearLayout nav=new LinearLayout(this);outer.addView(nav);String[] names={"Таймер","Схема","История","Опции"};
  for(int i=0;i<4;i++){final int n=i;Button b=new Button(this);b.setText(names[i]);b.setTextSize(12);style(b,i==tab);LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,-2,1);lp.setMargins(dp(2),dp(8),dp(2),dp(8));nav.addView(b,lp);b.setOnClickListener(v->{tab=n;draw();});}
  ScrollView scroll=new ScrollView(this);outer.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));body=new LinearLayout(this);body.setOrientation(1);scroll.addView(body);
  if(tab==0)home();else if(tab==1)scheme();else if(tab==2)history();else options();
 }
 void home(){int day=Data.day(this);
  if(!Data.p(this).contains("start")){text("С какого дня курса начинаем?",24);button("Выбрать текущий день курса",this::pickDay);text("Можно начать пользоваться приложением в любой день курса с 1-го по 25-й. Укажи также, сколько таблеток уже принято сегодня.",17);return;}
  if(day<1){text("Начало курса: "+Data.p(this).getString("start",""),22);return;}
  if(day>25){text("25 дней курса завершены",26);text("Курс автоматически не продлевается.",18);return;}
  int count=Data.count(this),limit=Data.limit(day);text("День "+day+" из 25",27);text("Учтено сегодня: "+count+" / "+limit,22);text("По 1 таблетке за приём. Интервал: "+intervalText(day),16);
  clock=text("",28);refreshClock();
  if(!Alarms.exact(this)||!Alarms.notifications(this)){text("Разрешения для напоминаний не готовы. Проверь опции перед запуском таймера.",17);button("Настроить напоминания",()->{tab=3;draw();});}
  if(count<limit)button("Принял таблетку — запустить таймер",this::confirmDose);
  else text(day==25?"Последний день курса: все приёмы учтены.":day>=21?"Сегодня приём учтён. Проверь, запущен ли таймер 24 часа.":"На сегодня все приёмы учтены. Первый приём нового дня отмечается вручную.",18);
  if(Data.imported(this)>0)text("Из них указано при настройке: "+Data.imported(this)+". Время этих приёмов не задано; таймер по ним автоматически не запускается.",15);
  text("Нажимай кнопку только после фактического приёма. Уведомление не подтверждает приём и не запускает следующий отсчёт.",15);
 }
 String intervalText(int d){return d<=3?"2 часа":d<=12?"2 часа 30 минут":d<=16?"3 часа":d<=20?"5 часов":"24 часа";}
 void refreshClock(){if(failed)return;if(renderedDay!=Data.day(this)){draw();return;}if(clock==null)return;long due=Data.p(this).getLong("due",0);if(due==0){clock.setText("Таймер не запущен");return;}long left=due-System.currentTimeMillis();if(left<=0){clock.setText("Интервал завершён\nОжидается твоя отметка");return;}long sec=(left+999)/1000;clock.setText(String.format(java.util.Locale.ROOT,"%02d:%02d:%02d",sec/3600,sec/60%60,sec%60)+"\nДо напоминания\n"+Data.time(due));}
 void confirmDose(){int day=Data.day(this);if(day<1||day>25||Data.count(this)>=Data.limit(day)){draw();return;}
  if(Data.p(this).getLong("due",0)>System.currentTimeMillis()){toast("Текущий интервал ещё не завершён. Ошибочную отметку можно исправить в истории.");return;}
  if(!Alarms.exact(this)||!Alarms.notifications(this)){toast("Разреши уведомления и точные напоминания в опциях");return;}
  new AlertDialog.Builder(this).setTitle("Подтвердить приём?").setMessage("Отметить одну фактически принятую таблетку? Новый отсчёт начинается с момента подтверждения.").setNegativeButton("Отмена",null).setPositiveButton("Принял",(d,w)->{try{
   int current=Data.day(this);if(current!=day||Data.count(this)>=Data.limit(current)){draw();return;}
   int next=Data.count(this)+1;boolean timer=current<25&&(current>=21||next<Data.limit(current));long due=timer?System.currentTimeMillis()+Data.interval(current):0;
   Alarms.cancel(this);if(due>0)Alarms.schedule(this,due);try{Data.add(this,due);}catch(RuntimeException e){Alarms.cancel(this);throw e;}draw();
  }catch(RuntimeException e){failure(e);}}).show();
 }
 void scheme(){text("Твоя схема курса",24);text("1–3-й день: 6 приёмов, каждые 2 часа\n\n4–12-й день: 5 приёмов, каждые 2 часа 30 минут\n\n13–16-й день: 4 приёма, каждые 3 часа\n\n17–20-й день: 3 приёма, каждые 5 часов\n\n21–25-й день: 1 приём, интервал 24 часа",19);text("Везде — по 1 таблетке. Это пользовательская схема, а не медицинское назначение. Корректность дозировки приложением не проверяется.",15);text("День меняется по календарю в полночь. Неотмеченные приёмы не переносятся. На этапах 1–20 после последнего приёма таймер не запускается; первый приём следующего дня отмечается вручную. На 21–24-й дни таймер равен 24 часам; после приёма 25-го дня он не запускается.",15);}
 void history(){text("История отметок",24);String date=Data.p(this).getString("importDate","");int imported=Data.p(this).getInt("importCount",0);if(imported>0)text(date+": при настройке учтено "+imported+" приёмов без времени. Это не записи подтверждённых таймером приёмов.",16);
  JSONArray h=Data.history(this);if(h.length()==0){text("Новых отметок пока нет",18);return;}
  button("Исправить последнюю отметку",()->new AlertDialog.Builder(this).setTitle("Удалить последнюю отметку?").setMessage("Последняя запись удалится, активный таймер отменится. Предыдущий таймер автоматически не восстанавливается. Это исправление записи, не отмена фактического приёма.").setNegativeButton("Нет",null).setPositiveButton("Удалить",(d,w)->{JSONArray old=Data.history(this),fresh=new JSONArray();for(int i=0;i<old.length()-1;i++)fresh.put(old.opt(i));Alarms.cancel(this);Data.p(this).edit().putString("history",fresh.toString()).putLong("due",0).putLong("alerted",0).apply();draw();}).show());
  for(int i=h.length()-1;i>=0;i--){JSONObject o=h.optJSONObject(i);if(o!=null)text(Data.time(o.optLong("time"))+" · день "+o.optInt("day")+" · 1 таблетка",17);}
 }
 void options(){text("Настройки",24);text("Разработано Renoviso · версия 1.1",18);
  button("Тема: "+Data.p(this).getString("theme","system").replace("system","Как в системе").replace("light","Светлая").replace("dark","Тёмная"),()->{String[] keys={"system","light","dark"};new AlertDialog.Builder(this).setTitle("Тема").setItems(new String[]{"Как в системе","Светлая","Тёмная"},(d,w)->{Data.p(this).edit().putString("theme",keys[w]).apply();recreate();}).show();});
  text("Уведомления: "+(Alarms.notifications(this)?"разрешены":"выключены")+"\nТочные напоминания: "+(Alarms.exact(this)?"разрешены":"не разрешены"),17);
  button("Разрешить уведомления",()->{if(Build.VERSION.SDK_INT>=33&&checkSelfPermission("android.permission.POST_NOTIFICATIONS")!=android.content.pm.PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{"android.permission.POST_NOTIFICATIONS"},5);else startActivity(new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE,getPackageName()));});
  button("Разрешить точные напоминания",()->{if(Build.VERSION.SDK_INT>=31)startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,Uri.parse("package:"+getPackageName())));else toast("Отдельное разрешение не требуется");});
  button("Восстановить активное напоминание",()->{Alarms.restore(this);toast("Если есть таймер и разрешение, напоминание запланировано заново");});
  text("Текущий день курса: "+Data.day(this),19);button("Выбрать день курса / начать заново",this::pickDay);
  text("Изменение дня после подтверждения очищает историю и отменяет текущий таймер. Данные только на телефоне, интернет не используется.",15);
  text("Звук зависит от канала уведомлений и режима «Не беспокоить». После перезагрузки восстановление возможно после первой разблокировки. После принудительной остановки снова открой приложение. Проверь уведомления при заблокированном экране и не полагайся на приложение как на единственное напоминание.",15);
 }
 void pickDay(){
  LinearLayout form=new LinearLayout(this);form.setOrientation(1);form.setPadding(dp(20),dp(8),dp(20),dp(8));
  TextView label=new TextView(this);label.setText("Сегодня день курса (1–25)");label.setTextColor(fg);form.addView(label);
  NumberPicker day=new NumberPicker(this);day.setMinValue(1);day.setMaxValue(25);day.setWrapSelectorWheel(false);day.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);int current=Data.day(this);day.setValue(current>=1&&current<=25?current:1);form.addView(day);
  TextView label2=new TextView(this);label2.setText("Уже принято сегодня, до настройки");label2.setTextColor(fg);form.addView(label2);
  NumberPicker taken=new NumberPicker(this);taken.setMinValue(0);taken.setMaxValue(Data.limit(day.getValue()));taken.setWrapSelectorWheel(false);taken.setDescendantFocusability(NumberPicker.FOCUS_BLOCK_DESCENDANTS);taken.setValue(Math.min(Data.count(this),Data.limit(day.getValue())));form.addView(taken);
  day.setOnValueChangedListener((picker,old,newDay)->{int value=Math.min(taken.getValue(),Data.limit(newDay));taken.setValue(0);taken.setMaxValue(Data.limit(newDay));taken.setValue(value);});
  ScrollView scroll=new ScrollView(this);scroll.addView(form);
  new AlertDialog.Builder(this).setTitle("Начать с любого дня").setView(scroll).setNegativeButton("Отмена",null).setPositiveButton("Продолжить",(dialog,which)->{
   final int chosen=day.getValue(),count=taken.getValue();
   new AlertDialog.Builder(this).setTitle("Сегодня день "+chosen).setMessage("Учесть уже принятых сегодня: "+count+". История текущего курса будет очищена, активный таймер отменён.\n\nПрошедшие дни не будут отмечены принятыми. Автоматический отсчёт по уже принятым таблеткам не запускается: время их приёма неизвестно. Следующий таймер запускается новой ручной отметкой.")
   .setNegativeButton("Отмена",null).setPositiveButton("Сохранить",(d,w)->{
    Alarms.cancel(this);String today=LocalDate.now().toString();boolean ok=Data.p(this).edit().putString("start",LocalDate.now().minusDays(chosen-1).toString()).putString("history","[]").putString("importDate",today).putInt("importCount",count).putLong("due",0).putLong("alerted",0).commit();if(!ok){toast("Не удалось сохранить настройки");return;}tab=0;draw();
   }).show();
  }).show();
 }
 void toast(String message){Toast.makeText(this,message,Toast.LENGTH_LONG).show();}
 void failure(Throwable error){if(failed)return;failed=true;clock=null;String report="Курс без дыма 1.1 / Renoviso\nAndroid "+Build.VERSION.RELEASE+"\n"+android.util.Log.getStackTraceString(error);LinearLayout panel=new LinearLayout(this);panel.setOrientation(1);panel.setPadding(dp(16),dp(60),dp(16),dp(24));panel.setBackgroundColor(Color.WHITE);Button copy=new Button(this);copy.setText("Скопировать ошибку");panel.addView(copy);copy.setOnClickListener(v->{((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("Ошибка",report));toast("Скопировано");});ScrollView scroll=new ScrollView(this);panel.addView(scroll);TextView t=new TextView(this);t.setTextColor(Color.BLACK);t.setTextIsSelectable(true);t.setText(report);scroll.addView(t);setContentView(panel);}
}
